import requests
import json

$access_key = 'aa83c4e59ee6378790e21824fc4429e3';

$phone_number = '17802429398';

$ch = curl_init('http://apilayer.net/api/validate?access_key='.$access_key.'&number='.$phone_number.'');  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$json = curl_exec($ch);
curl_close($ch);

$validationResult = json_decode($json, true);

$validationResult['valid'];
$validationResult['country_code'];
$validationResult['carrier'];