import nexmo

client = nexmo.Client(key='8deb31e9', secret='BA4j8jscwiLCxWYP')

client.send_message({
    'from': '14372662723',
    'to': '17802429398',
    'text': 'Hello from Vonage',
})