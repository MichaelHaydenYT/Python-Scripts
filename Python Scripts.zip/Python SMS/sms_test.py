from twilio.rest import Client

# Your Account SID from twilio.com/console
account_sid = "ACc162bf4b931dd03fdcc4d0c8321a0c8b"
# Your Auth Token from twilio.com/console
auth_token  = "73e7d3431b2efc9e3f78ddecf4c1278e"

client = Client(account_sid, auth_token)

message = client.messages.create(
    to="+17809640502", 
    from_="+12565379595",
    body="Operation Arrowhead")

print(message.sid)